﻿using System;
using System.Collections.Generic;
using System.Text;

namespace congestion.calculator
{
    public static class TollCalculator
    {
       

        private static bool IsTollFreeVehicle(IVehicle vehicle)
        {
            if (vehicle == null) return false;

            return vehicle.VehicleType == TollFreeVehicles.Motorcycle ||
                   vehicle.VehicleType == TollFreeVehicles.Tractor ||
                   vehicle.VehicleType == TollFreeVehicles.Emergency ||
                   vehicle.VehicleType == TollFreeVehicles.Diplomat ||
                   vehicle.VehicleType == TollFreeVehicles.Foreign ||
                   vehicle.VehicleType == TollFreeVehicles.Military;
        }

        public static int GetTollFee(DateTime date, IVehicle vehicle)
        {
            List<TollFee> fee = Configuratuin.ReadFromSetting();

            if (IsTollFreeDate(date) || IsTollFreeVehicle(vehicle)) return 0;

            int hour = date.Hour;
            int minute = date.Minute;

            if ((hour == fee[0].Hour1 && minute >= fee[0].Minute1 && minute <= fee[0].Minute2) ||
                    (hour >= fee[1].Hour1 && hour <= fee[1].Hour2 && minute >= fee[1].Minute1 && minute <= fee[1].Minute2) ||
                    (hour == fee[2].Hour1 && minute >= fee[2].Minute1 && minute <= fee[2].Minute2))
                return fee[0].Fee;
            else if ((hour == fee[3].Hour1 && minute >= fee[3].Minute1 && minute <= fee[3].Minute2) ||
                    (hour == fee[4].Hour1 && minute >= fee[4].Minute1 && minute <= fee[4].Minute2) ||
                    (hour == fee[5].Hour1 && minute >= fee[5].Minute1 && minute <= fee[5].Minute2) ||
                    (hour == fee[6].Hour1 && minute >= fee[6].Minute1 && minute <= fee[6].Minute2))
                return fee[3].Fee;
            else if ((hour == fee[7].Hour1 && minute >= fee[7].Minute1 && minute <= fee[7].Hour1) ||
                     (hour == fee[8].Hour1 && minute >= fee[8].Minute1 || hour == fee[8].Hour1 && minute <= fee[8].Hour1))
                return fee[7].Fee;
            else return 0;
        }

        private static Boolean IsTollFreeDate(DateTime date)
        {
            int year = date.Year;
            int month = date.Month;
            int day = date.Day;

            if (date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday) return true;

            if (year == 2013)
            {
                if (month == 1 && day == 1 ||
                    month == 3 && (day == 28 || day == 29) ||
                    month == 4 && (day == 1 || day == 30) ||
                    month == 5 && (day == 1 || day == 8 || day == 9) ||
                    month == 6 && (day == 5 || day == 6 || day == 21) ||
                    month == 7 ||
                    month == 11 && day == 1 ||
                    month == 12 && (day == 24 || day == 25 || day == 26 || day == 31))
                {
                    return true;
                }
            }
            return false;
        }
    }
}
