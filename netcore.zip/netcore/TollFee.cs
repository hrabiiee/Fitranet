﻿using System;
using System.Collections.Generic;
using System.Text;

namespace congestion.calculator
{
    internal class TollFee
    {
        public int Hour1 { get; set; }
        public int Hour2 { get; set; }
        public int Minute1 { get; set; }
        public int Minute2  { get; set; }
        public int Fee { get; set; }
    }
}
