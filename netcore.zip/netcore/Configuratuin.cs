﻿using System;
using System.Collections.Generic;
using System.Text;

namespace congestion.calculator
{
    public static class Configuratuin
    {
        public static List<TollFee> ReadFromSetting() {
            return new List<TollFee>();
        }
    }
}
