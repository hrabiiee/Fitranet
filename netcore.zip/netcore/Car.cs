using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace congestion.calculator
{
    public class Car : IVehicle
    {

        public Car()
        {}

        public Car(TollFreeVehicles toolFreeVehicle)
        {
            this.VehicleType = toolFreeVehicle;
        }

        public TollFreeVehicles VehicleType { get ; set ; }

      
    }
}